module.exports=[2220,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_harta_page_actions_1-jtkpv.js.map