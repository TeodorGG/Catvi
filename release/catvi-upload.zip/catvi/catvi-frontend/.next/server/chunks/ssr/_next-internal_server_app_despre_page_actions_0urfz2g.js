module.exports=[64350,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_despre_page_actions_0urfz2g.js.map