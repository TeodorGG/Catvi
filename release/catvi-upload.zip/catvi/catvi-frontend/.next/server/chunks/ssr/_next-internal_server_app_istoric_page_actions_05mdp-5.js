module.exports=[4681,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_istoric_page_actions_05mdp-5.js.map